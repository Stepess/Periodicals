insert into paid_publication (user_id, publication_id) values 
(2,4), (4,2);