insert into payment (bill, date_time_of_payment, subscription_id, user_id) values 
(213, '2018-01-10 18:02:23', 4, 2),
(121, '2018-02-12 12:12:21', 2, 4);