#insert into subscription_has_publication values (1,1,'2018-08-20','2018-10-10');
#insert into subscription_has_publication values (1,2,'2018-08-20','2018-10-10');
#insert into subscription_has_publication values (2,2,'2018-08-31','2018-10-29');
insert into subscription_has_publication values (3,2,'2018-08-31','2018-10-29');