insert into subscription (state, start_date, end_date, user_id, publication_id) values 
('paid', '2018-08-20', '2018-09-20', 2, 4),
('unpaid', '2018-04-20', '2018-10-20', 3, 1),
('paid', '2018-01-10', '2018-10-10', 4, 2),
('unpaid', '2018-07-20', '2018-10-20', 1, 3);subscriptionpublication
