package controller.exception;

public class AccessDeniedException extends RuntimeException {
}
