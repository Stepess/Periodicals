package controller.servlet;


import controller.command.Command;
import controller.command.CommandFactory;
import controller.utils.SessionRequestContent;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class Servlet extends HttpServlet {


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }

    private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        SessionRequestContent content = new SessionRequestContent();
        CommandFactory commandFactory = new CommandFactory();
        Command command = commandFactory.getCommandFromRequest(request);

        content.extractValues(request);
        String page = command.execute(content);
        System.out.println("bef " + request.getSession().getAttribute("role"));
        content.acceptChanges(request);
        System.out.println(request.getSession().getAttribute("role"));
        if (page.contains("redirect:")) {
            response.sendRedirect(request.getContextPath() + page.replace("redirect:", ""));
        } else {
            request.getRequestDispatcher(page).forward(request, response);
        }

    }
}
