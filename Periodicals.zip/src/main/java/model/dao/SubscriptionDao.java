package model.dao;

import model.entity.Subscription;

public interface SubscriptionDao extends GenericDao<Subscription> {
}
