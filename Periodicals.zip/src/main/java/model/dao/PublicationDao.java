package model.dao;

import model.entity.Publication;

public interface PublicationDao extends GenericDao<Publication>{
}
