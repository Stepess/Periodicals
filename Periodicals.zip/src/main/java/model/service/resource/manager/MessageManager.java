package model.service.resource.manager;

public class MessageManager {
}
