package model.service.resource.manager;

public interface ResourceManager {
    String getProperty(String key);
}
